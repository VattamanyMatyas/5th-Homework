public class RandomNamer implements Namer {
    private int length;
    private java.util.Random rnd;
    private final String ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"; 
    //Még mindig baja van az ALPHABET-tel. nem tudom miért, pedig konstans.

    public RandomNamer(java.util.Random rnd, int length){
        this.rnd = rnd;
        this.length = length;
    }
    public void rename(FileSystemEntry newEntry){
        String ujNev = new String();
        for(int i = 0; i < length; i++){

            int szam = rnd.nextInt(0-ALPHABET.length());
            char karakter = ALPHABET.charAt(szam);
            ujNev += karakter;
        }
        newEntry.setName(ujNev);    
    }
}
