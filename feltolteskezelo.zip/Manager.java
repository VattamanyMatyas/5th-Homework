public class Manager {
    private Namer namer;
    private Folder imagesFolder;
    private Folder etcFolder;

    public Manager(Namer namer, Folder rootFolder){
        this.namer = namer;
        imagesFolder = new Folder(rootFolder, "images");
        etcFolder = new Folder(rootFolder, "etc");
    }   

    public File upload(String fileName, long size){
        String wordegy = ".jpg";
        String wordketto = ".png";
        String wordharom = ".gif";
        if(fileName.endsWith(wordegy) == true || fileName.endsWith(wordketto) == true || fileName.endsWith(wordharom) == true){
           File objektum = new File(imagesFolder, fileName, size);
           namer.rename(objektum);
           System.out.println("Stored " + objektum.getName() + " at " + objektum.fullPath() + "\n");
           System.out.println("Images size: " + objektum.size() + " bytes\n");
           return objektum;
        }
        else{
           File objektum = new File(etcFolder, fileName, size);
           namer.rename(objektum);
           System.out.println("Stored " + objektum.getName() + " at " + objektum.fullPath() + "\n");
           System.out.println("Etc size: " + objektum.size() +" bytes\n");
           return objektum;
        }
        
    }
    
}
