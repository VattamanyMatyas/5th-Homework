public interface Namer {
    
    public void rename(FileSystemEntry newEntry);
    
}
