public class Folder extends FileSystemEntry{

    //attributom
    private FileSystemEntry[] children = null;


    //konstruktor
    public Folder(Folder parent, String name){
        setParent(parent);
        setName(name);
        
    }   


    //metodus
    public void addChild(FileSystemEntry child){
        FileSystemEntry[] childrenketto = new FileSystemEntry[1];
        if(children == null){
            childrenketto[0] = child;
            children = childrenketto;
        }
        else{
            childrenketto = new FileSystemEntry[children.length+1]; //masodjara mar nem deklaralom, csak uj erteket adok
            for(int i = 0; i < children.length; i++){
                childrenketto[i] = children[i];
                childrenketto[i+1] = child;
            }
            children = childrenketto;
        }
    }
    public long size(){             //absztrakt metódus megvalósítása(FileSystemEntry) az inheritáló classban(Folder)
        if(children == null){
            return 0;
        }
        else{
            long osszmeret = 0;
            for(int i = 0; i < children.length; i++){
                osszmeret += children[i].size();
            }
            return osszmeret; 
        }                          
    }
}
