public abstract class FileSystemEntry {
    private Folder parent; 
    private String name;

    public FileSystemEntry(){

    }

    public FileSystemEntry(Folder parent, String name){
        this.parent = parent;
        this.name = name;

        if(this.parent != null){        
            parent.addChild(this);
        }
    }

    public abstract long size();

    public String fullPath(){   
        if(parent == null){
            return name;
        }
        else{
            return parent.fullPath() + "/" + this.name;
        }
    }

    public void setName(String newName) {
        this.name = newName;
    }

    public String getName() {
        return name;
    }

    public void setParent(Folder parent) {
        this.parent = parent;
    }

    public Folder getParent() {
        return parent;
    }

}