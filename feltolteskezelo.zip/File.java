public class File extends FileSystemEntry {

    //attributum
    private long size;

    //konstruktor
    public File(Folder parent, String name, long size){
        setParent(parent);
        setName(name);
        this.size = size;
    }


    //absztrakt method amit a FileSystemEntry-ből hívtunk meg. (egy már létezik a Folder class-ban is)
    public long size(){
        return size;
    }    


}
