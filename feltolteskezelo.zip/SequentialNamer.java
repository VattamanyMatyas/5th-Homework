public class SequentialNamer implements Namer {
    private int index = 1;


    @Override
    public void rename(FileSystemEntry newEntry) {
        newEntry.setName(newEntry.getName() + "_" + index);
        index += 1;
    }
}
